setwd("C:\\Users\\ashen\\OneDrive\\Desktop\\IT24104140")

n <- 50
p <- 0.85

p_at_least_47 <- 1 - pbinom(46, size = n, prob = p)  
p_at_least_47

p47 <- dbinom(47, size=n, prob=p)
p48 <- dbinom(48, size=n, prob=p)
p49 <- dbinom(49, size=n, prob=p)
p50 <- dbinom(50, size=n, prob=p)
p47; p48; p49; p50
sum47to50 <- sum(dbinom(47:50, size=n, prob=p))
sum47to50

lambda <- 12  

p_eq_15 <- dpois(15, lambda = lambda)
p_eq_15

cat("Problem 1: X ~ Binomial(n=50, p=0.85)\n")
cat("P(X >= 47) =", format(p_at_least_47, digits=10), "\n\n")

cat("Problem 2: X ~ Poisson(lambda=12)\n")
cat("P(X = 15) =", format(p_eq_15, digits=10), "\n")

n <- 50
p <- 0.85

p_at_least_47 <- 1 - pbinom(46, size = n, prob = p)  
p_at_least_47

p47 <- dbinom(47, size=n, prob=p)
p48 <- dbinom(48, size=n, prob=p)
p49 <- dbinom(49, size=n, prob=p)
p50 <- dbinom(50, size=n, prob=p)
p47; p48; p49; p50
sum47to50 <- sum(dbinom(47:50, size=n, prob=p))
sum47to50

lambda <- 12   

p_eq_15 <- dpois(15, lambda = lambda)
p_eq_15

cat("Problem 1: X ~ Binomial(n=50, p=0.85)\n")
cat("P(X >= 47) =", format(p_at_least_47, digits=10), "\n\n")

cat("Problem 2: X ~ Poisson(lambda=12)\n")
cat("P(X = 15) =", format(p_eq_15, digits=10), "\n")

n <- 50; p <- 0.85
1 - pbinom(46, size=n, prob=p)

dbinom(47,50,0.85)
dbinom(48,50,0.85)
dbinom(49,50,0.85)
dbinom(50,50,0.85)
sum(dbinom(47:50,50,0.85))

lambda <- 12
dpois(15, lambda)

